//*****************************************************
//                     MIMIC
//  By: Jocelyn Lee, Lauren DeFelice, and Kayla Kohr
//       ECE 3130-001: Microcomputer Systems
//             Due: April 30th, 2025
//*****************************************************
//
//***********************************
//           INCLUDES
//***********************************
#include "main.h"
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>  
#include <string.h>
#include "stm32l4xx_hal.h"
//
//***********************************
//          DEFINITIONS
//***********************************
#define BUZZER_PIN GPIO_PIN_9
#define BUZZER_PORT GPIOC
#define MAX_PATTERN 100
//
//***********************************
//        GLOBAL VARIABLES
//***********************************
uint8_t blink[MAX_PATTERN];
uint8_t button[MAX_PATTERN];
int patternlength = 1;
int loss = 0;
int lives = 3;
//
//***********************************
//       FUNCTION PROTOTYPES
//***********************************
//
//************ System ***************
void Delay(uint32_t delay){
  for (uint32_t n = 0; n < delay; n++)
  {
    for (uint32_t i = 0; i < 138; i++)
    {
      __asm("nop");
    }
  }
}
void SystemClock_Config(void);
static void MX_GPIO_Init(void);

//*********** Music *****************
void delay_us(uint32_t us);
void tone(GPIO_TypeDef *port, uint16_t pin, uint32_t freq, uint32_t duration_ms);
void play_startup_song(void);
void play_gameover_song(void);
void play_correct(void);
void play_wrong(void);

//************ LCD ******************
void LCD_Init();
void Write_Instr_LCD(uint8_t code);
void Write_Char_LCD(uint8_t code);
void Write_String_LCD(char *temp); 
void LCD_nibble_write(uint8_t temp, uint8_t s); 

//************* KEYPAD **************
typedef struct keypad_button_t {
  uint8_t row;
  uint8_t col;
} keypad_button;
void keypad_init(void);
bool is_key_pressed(void);
keypad_button get_key(void);
char key_to_char(keypad_button key);

//************* GAME ****************
void countdown_begin(void);
void generate_pattern(int length);
void show_pattern(int length);
void get_player_input(int length);
bool check_pattern(int length);
void game_over(int final_score);
//
//***********************************
//         MAIN FUNCTION   
//***********************************
int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    LCD_Init();
    keypad_init();
    srand(HAL_GetTick());

    // Enable cycle counter
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
		
		//Welcome Screen
    Write_String_LCD("Welcome to MIMIC");
		Write_Instr_LCD(0xC0);
		Write_String_LCD("..o.o.o..o.o.o..");
		play_startup_song();
    Delay(3000);
    Write_Instr_LCD(0x01);
    Write_String_LCD("Press any keypad");
    Write_Instr_LCD(0xC0);
    Write_String_LCD("button to start!");
		
		//Pause game until user pushes keypad button
    while (!is_key_pressed()) {}
    
		//Begin count down to start game
		Delay(200);
    Write_Instr_LCD(0x01);
    countdown_begin(); 
			
		//External LEDs stay on until a round is lost
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);


    while (1) {
			  //Display "ROUND: " and number
        Write_Instr_LCD(0x01); // Clear LCD
        char buffer[16];
        sprintf(buffer, "ROUND: %d", patternlength);
        Write_String_LCD(buffer); 
        HAL_Delay(1000);
				
				//Generates and shows pattern of that round
        generate_pattern(patternlength); 
        show_pattern(patternlength);  
			
				//Goes to the function where user must repeat pattern
        get_player_input(patternlength); 
				
				//if the user makes three mistakes, they will get sent
				//to the game over screen
        if (loss == 3) {  
            game_over(patternlength - 1); 
        }
				
				//If the pattern is correct and they still have lives,
				//display the correct screen and move on to the next round
        if (lives > 0 && check_pattern(patternlength)) {
            Write_Instr_LCD(0x01);
						Write_String_LCD("  MIMICTASTIC!");
						play_correct(); 
            patternlength++; 
            Delay(1000);
        }
				//Debouncing and clearing the screen 
				//(resets for the next round basically)
        HAL_Delay(1000);
        Write_Instr_LCD(0x01);
    }
}
//
//***********************************
//        MX_GPIO FUNCTION
//***********************************
static void MX_GPIO_Init(void) {
    //******** BUZZER PINS *********
    __HAL_RCC_GPIOC_CLK_ENABLE(); // Enable GPIOC for PC9
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = BUZZER_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    HAL_GPIO_Init(BUZZER_PORT, &GPIO_InitStruct);
  
    //******** LED GAME ***********
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    
    // Configure PA1, PA0 (LEDs) as output
    GPIO_InitStruct.Pin = GPIO_PIN_1 | GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM; 
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    
    // Configure PA7, PA8 (LEDs) as output
    GPIO_InitStruct.Pin = GPIO_PIN_7 | GPIO_PIN_8;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM; 
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    // Configure PB8, PB9, PB10, PB11 (Buttons) as input with pull-down
    GPIO_InitStruct.Pin = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN; 
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
		
		// Configure PC0, PC1, PB0 (external LEDs) as output
    GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; 
    GPIO_InitStruct.Pull = GPIO_NOPULL;         
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM; 
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
		
    GPIO_InitStruct.Pin = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; 
    GPIO_InitStruct.Pull = GPIO_NOPULL;        
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM; 
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
//
//***********************************
//       GAMEPLAY FUNCTIONS  
//***********************************
void countdown_begin(void) {
	//This functions explains to the player what to do
	//and then begins counting down from 3 before the 
	//game starts! Also plays a buzzer for each number
    Write_String_LCD("Repeat LED cycle");
    Write_Instr_LCD(0xC0);
    Write_String_LCD("using SW2 - SW5.");
    Delay(3000);

    Write_Instr_LCD(0x01);
    Write_String_LCD("Game begins in");
    Write_Instr_LCD(0xC0);
    Delay(1000);

    Write_Instr_LCD(0xC0 + 7);
    Write_String_LCD("3");
		tone(BUZZER_PORT, BUZZER_PIN, 392, 400);
    Delay(1000);
    Write_Instr_LCD(0xC0 + 7);
    Write_String_LCD("2");
		tone(BUZZER_PORT, BUZZER_PIN, 440, 400);
    Delay(1000);
    Write_Instr_LCD(0xC0 + 7);
    Write_String_LCD("1");
		tone(BUZZER_PORT, BUZZER_PIN, 523, 400);
    Delay(1000);
    Write_Instr_LCD(0xC0 + 6);
    Write_String_LCD("GO!!!");
		tone(BUZZER_PORT, BUZZER_PIN, 659, 500);
    Delay(1000);
    Write_Instr_LCD(0x01); 
}
void generate_pattern(int length) {
	//Randomly creates a sequence of LEDs that
	//must be memorized by the player. The
	//pattern is as big as the length
	//meaning round 1 equals a pattern of 1 LED
    for (int i = 0; i < length; i++) {
        blink[i] = rand() % 4;
    }
}
void show_pattern(int length) {
	//Takes the information from generate_pattern, and
	//displays the generated LED squence on LEDs 0-3
    for (int i = 0; i < length; i++) {
        if (blink[i] == 0)
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
        else if (blink[i] == 1)
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
        else if (blink[i] == 2)
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);
        else if (blink[i] == 3)
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_SET);

        HAL_Delay(500);

        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_RESET);

        HAL_Delay(80);
    }
}
void get_player_input(int length) {
	//Waits for the user to input their answer,
	//blinks the associated LED, records value
	//in the button[] array, compares it to the
	//generated sequence, and if wrong, decreases
	//lives, updates external LEDs, and calls to
	//game_over() if no lives left
    for (int i = 0; i < length; i++) {
        // Wait for button press
        while (
            HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8) == GPIO_PIN_RESET &&
            HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9) == GPIO_PIN_RESET &&
            HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == GPIO_PIN_RESET &&
            HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == GPIO_PIN_RESET
        ) {}

        // Detect which button is pressed
        if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8) == GPIO_PIN_SET) {
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET); // LED for Button 1
            button[i] = 0;
        } else if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9) == GPIO_PIN_SET) {
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET); // LED for Button 2
            button[i] = 1;
        } else if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == GPIO_PIN_SET) {
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET); // LED for Button 3
            button[i] = 2;
        } else if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == GPIO_PIN_SET) {
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_SET); // LED for Button 4
            button[i] = 3;
        }

        // Wait for button release
        while (
            HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8) == GPIO_PIN_SET ||
            HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9) == GPIO_PIN_SET ||
            HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == GPIO_PIN_SET ||
            HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == GPIO_PIN_SET
        ) {}

        HAL_Delay(50); // Debounce

        // Turn off LEDs after input
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_RESET);

        // Check if the button pressed is wrong
        if (button[i] != blink[i]) {
            loss++; 
            Write_Instr_LCD(0x01);
            Write_String_LCD("OH NO...");
            Write_Instr_LCD(0xC0);
            lives--; 

            if (lives == 0) {
								HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
                game_over(patternlength - 1);
            } else {
								if(lives==1){
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
									Write_Char_LCD(lives + '0');
									Write_String_LCD(" Attempt Left!");
									play_wrong();
									Delay(1000);
								}
								else{
									HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET);
									Write_Char_LCD(lives + '0');
									Write_String_LCD(" Attempts Left!");
									play_wrong();
									Delay(1000);
								}		
            }
            break;
        }
    }
}
bool check_pattern(int length) {
	//compares button[] and blink[] to confirm
	//if the user input matches the sequence
    for (int i = 0; i < length; i++) {
        if (blink[i] != button[i]) {
            return false;
        }
    }
    return true;
}
void game_over(int final_score) {
	//Displays Game Over and shows the number 
	//of completed rounds before offering the 
	//user to play again.
    Write_Instr_LCD(0x01);
    Write_String_LCD("_-_GAME OVER!_-_");
    Write_Instr_LCD(0xC0);
		char buffer[16];
    sprintf(buffer, "High Score: %d", final_score);
    Write_String_LCD(buffer);
    play_gameover_song();  // Play the song after Game Over displayed

    HAL_Delay(2000);  // Wait 2 seconds after song

    Write_Instr_LCD(0x01);  // Clear screen
    Write_String_LCD("Press any keypad");
    Write_Instr_LCD(0xC0);
    Write_String_LCD("button to replay");

    while (!is_key_pressed()) {}
		HAL_NVIC_SystemReset();
}
//
//***********************************
//        BUZZER FUNCTIONS 
//***********************************
void delay_us(uint32_t us) {
	//Microsecond delay for buzzer functions
	//Makes the buzzers tone sound more appealing
	//uses DWT->CYCCNT counter 
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (HAL_RCC_GetHCLKFreq() / 1000000);
    while ((DWT->CYCCNT - start) < ticks);
}
void tone(GPIO_TypeDef *port, uint16_t pin, uint32_t freq, uint32_t duration_ms) {
  //Generates a square wave to produce a tone
		if (freq == 0) {
        Delay(duration_ms);
        return;
    }
    uint32_t delay = 1000000 / (freq * 2); // Half-period
    uint32_t cycles = (freq * duration_ms) / 1000;

    for (uint32_t i = 0; i < cycles; i++) {
        HAL_GPIO_WritePin(port, pin, GPIO_PIN_SET);
        delay_us(delay);
        HAL_GPIO_WritePin(port, pin, GPIO_PIN_RESET);
        delay_us(delay);
    }
}
void play_startup_song(void) {
  //At the start of the game, this function
	//plays the created song from the buzzer
	//that is producing different frequencies 
	//though the tone function
		int melody[] = {
        523, 587, 659, 698, 784, 698, 659, 587, 523
    }; 
    
    int noteDurations[] = {
        8, 8, 8, 8, 4, 8, 8, 8, 4
    };
    
    for (int thisNote = 0; thisNote < 9; thisNote++) {
        int noteDuration = 1000 / noteDurations[thisNote];
        tone(BUZZER_PORT, BUZZER_PIN, melody[thisNote], noteDuration);
        int pauseBetweenNotes = noteDuration * 1.2;
        HAL_Delay(pauseBetweenNotes);
    }
}
void play_gameover_song(void) { 
	//Plays a short song to signify 
	//that the game is over
    tone(BUZZER_PORT, BUZZER_PIN, 440, 250); // A4
    HAL_Delay(100);
    tone(BUZZER_PORT, BUZZER_PIN, 392, 250); // G4
    HAL_Delay(100);
    tone(BUZZER_PORT, BUZZER_PIN, 349, 300); // F4
    HAL_Delay(100);
    tone(BUZZER_PORT, BUZZER_PIN, 262, 400); // C4
    HAL_Delay(100);
    tone(BUZZER_PORT, BUZZER_PIN, 196, 600); // G3 
}
void play_correct(void) {
	//A three tone ding for every correct round passed
    tone(BUZZER_PORT, BUZZER_PIN, 784, 200); // G5
    HAL_Delay(200);
    tone(BUZZER_PORT, BUZZER_PIN, 880, 200); // A5
    HAL_Delay(200);
    tone(BUZZER_PORT, BUZZER_PIN, 988, 200); // B5
    HAL_Delay(200);
}
void play_wrong(void) {
	//A three toned ding for an incorrect answer
    tone(BUZZER_PORT, BUZZER_PIN, 349, 200); // F4
    HAL_Delay(200);
    tone(BUZZER_PORT, BUZZER_PIN, 233, 200); // A#3
    HAL_Delay(200);
    tone(BUZZER_PORT, BUZZER_PIN, 196, 200); // G3
    HAL_Delay(200);
}
//
//***********************************
//          LCD FUNCTIONS  
//***********************************
//Functions provided by class slides
void LCD_Init(){ 
	uint32_t temp;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN; /* enable GPIOA clock */
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN; /* enable GPIOB clock */
	/*PB5 MOSI, PA10 /CS_7 latch , PA5 shift clock */
	/*PA5 and PA10 are outputs*/
	temp = GPIOA->MODER;
	temp &= ~(0x03<<(2*5)); temp|=(0x01<<(2*5));
	temp &= ~(0x03<<(2*10)); temp|=(0x01<<(2*10));
	GPIOA->MODER = temp;
	temp=GPIOA->OTYPER;
	temp &=~(0x01<<5);
	temp &=~(0x01<<10);
	GPIOA->OTYPER=temp;
	temp=GPIOA->PUPDR;
	temp&=~(0x03<<(2*5));
	temp&=~(0x03<<(2*10));
	GPIOA->PUPDR=temp;

	/*PB5 is output*/
	temp = GPIOB->MODER;
	temp &= ~(0x03<<(2*5));
	temp|=(0x01<<(2*5));
	GPIOB->MODER = temp;
	temp=GPIOB->OTYPER;
	temp &=~(0x01<<5);
	GPIOB->OTYPER=temp;
	temp=GPIOB->PUPDR;
	temp&=~(0x03<<(2*5));
	GPIOB->PUPDR=temp;			

	Delay(20);
	LCD_nibble_write(0x30,0);
	Delay(5);
	LCD_nibble_write(0x30,0);
	Delay(1);
	LCD_nibble_write(0x30,0);
	Delay(1);
	LCD_nibble_write(0x20,0);
	Delay(1);
	
	Write_Instr_LCD(0x28); 
	Write_Instr_LCD(0x0E); 
	Write_Instr_LCD(0x01);
	Write_Instr_LCD(0x06);
}
void Write_SR_LCD(uint8_t temp){ 
	int i; 
	uint8_t mask=0b10000000;
	
	for(i=0; i<8; i++) {
		if((temp&mask)==0)
			GPIOB->ODR&=~(1<<5);
		else
			GPIOB->ODR|=(1<<5);
		GPIOA->ODR&=~(1<<5); 
		GPIOA->ODR|=(1<<5);
		Delay(1);
		mask=mask>>1;
	}
	GPIOA->ODR|=(1<<10); GPIOA->ODR&=~(1<<10);
}
void LCD_nibble_write(uint8_t temp, uint8_t s){    
	if (s==0){ 
		temp=temp&0xF0;
		temp=temp|0x02;  
		Write_SR_LCD(temp);
    temp=temp&0xFD;  
    Write_SR_LCD(temp);	
	}
	else if (s==1) {
		temp=temp&0xF0;
		temp=temp|0x03; 
		Write_SR_LCD(temp);
		temp=temp&0xFD;
		Write_SR_LCD(temp); 
	}
}
void Write_Instr_LCD(uint8_t code){
	LCD_nibble_write(code&0xF0,0);
	code=code<<4;
	LCD_nibble_write(code,0);
}
void Write_Char_LCD(uint8_t code){
	LCD_nibble_write(code&0xF0,1);
	code=code<<4; 
	LCD_nibble_write(code,1);
}
void Write_String_LCD(char *temp) { 
	int i=0;
	while(temp[i]!=0){
		Write_Char_LCD(temp[i]); i=i+1;
	}
}
//
//***********************************
//       KEYPAD FUNCTIONS  
//***********************************
//Functions provided by class slides
void keypad_init(void){
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOB_CLK_ENABLE(); // Enable GPIOB clock

  // Setup pins B1-B4 as outputs
  GPIO_InitStruct.Pin = GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  // Setup pins B8-B11 as inputs, with pull-down registers
  GPIO_InitStruct.Pin = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
bool is_key_pressed(void){
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4, GPIO_PIN_SET);
  uint16_t row_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4, GPIO_PIN_RESET);
  return row_state == GPIO_PIN_RESET ? false : true;
}
keypad_button get_key(void){
  uint16_t col_mask = GPIO_PIN_1;
  uint16_t row_mask = GPIO_PIN_8;
  uint8_t col = 0xFF;
  uint8_t row = 0xFF;
  uint16_t row_state = 0x00;

  for (uint8_t i = 0; i < 4; ++i) {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, col_mask, GPIO_PIN_SET); // Set the current column to high
    row_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11);
    if (row_state == GPIO_PIN_SET) {
      col = i;
      break;
    }
    col_mask <<= 1;
  }
  for (uint8_t i = 0; i < 4; ++i) {
    if (HAL_GPIO_ReadPin(GPIOB, row_mask) == GPIO_PIN_SET) {
      row = i;
      break;
    }
    row_mask <<= 1;
  }
  if (col == 0xFF || row == 0xFF) {
    return (keypad_button){.row = 0xFF, .col = 0xFF};
  }
  return (keypad_button){.row = row, .col = col};
}
char key_to_char(keypad_button key){
  uint8_t key_id = ((key.row & 0x0F) << 4) | (key.col & 0x0F);
  char key_char = '\0';
	
  switch (key_id) {
    case 0x00:
      key_char = '1';
      break;
    case 0x01:
      key_char = '2';
      break;
    case 0x02:
      key_char = '3';
      break;
    case 0x03:
      key_char = 'A';
      break;
    case 0x10:
      key_char = '4';
      break;
    case 0x11:
      key_char = '5';
      break;
    case 0x12:
      key_char = '6';
      break;
    case 0x13:
      key_char = 'B';
      break;
    case 0x20:
      key_char = '7';
      break;
    case 0x21:
      key_char = '8';
      break;
    case 0x22:
      key_char = '9';
      break;
    case 0x23:
      key_char = 'C';
      break;
    case 0x30:
      key_char = '*';
      break;
    case 0x31:
      key_char = '0';
      break;
    case 0x32:
      key_char = '#';
      break;
    case 0x33:
      key_char = 'D';
      break;
  }
  return key_char;
}
//
//***********************************
//          STM32CubeMX 
//         Do Not Touch!   
//***********************************
// ! IMPORTANT ! This function is generated by STM32CubeMX and should not be modified
 void SystemClock_Config(void){
   RCC_OscInitTypeDef RCC_OscInitStruct = {0};
   RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
 
   // Configure the main internal regulator output voltage
   if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
   {
     Error_Handler();
   }
 
   // Initializes the RCC Oscillators according to the specified parameters
   //  in the RCC_OscInitTypeDef structure.
   RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
   RCC_OscInitStruct.MSIState = RCC_MSI_ON;
   RCC_OscInitStruct.MSICalibrationValue = 0;
   RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
   RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
   if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
   {
     Error_Handler();
   }
 
   // Initializes the CPU, AHB and APB buses clocks
   RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                               |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
   RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
   RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
   RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
   RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
 
   if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
   {
     Error_Handler();
   }
 }
 // This function is called whenever there is an error, such as illegal memory access
 void Error_Handler(void){
   // We don't really need to do anything for errors, so just stay here forever
   __disable_irq();
   while (1)
   {
   }
 }
 // ! IMPORTANT ! All code below this line is generated by STM32CubeMX and should not be modified
 #ifdef  USE_FULL_ASSERT
 /**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */